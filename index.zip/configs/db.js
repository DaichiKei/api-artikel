const mysql = require('mysql2/promise');
const dotenv = require('dotenv');
dotenv.config()

// Create the connection pool. The pool-specific settings are the defaults
const pool = mysql.createPool({
  host: process.env.HOST,
  user: process.env.USER,
  password: process.env.PASSWORD,
  database: process.env.DATABASE,
  waitForConnections: true,
  connectionLimit: 10, // Batasi jumlah koneksi
  queueLimit: 0 // Tidak ada batasan antrian
});

module.exports = pool;