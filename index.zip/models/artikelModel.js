const pool = require('../configs/db.js');

const createArtikel = async (data, tanggal) => {
    let conn;
    try {
        conn = await pool.getConnection();

        const [result] = await conn.query(
            `INSERT INTO artikel (id, judul, penulis, isi, tanggal, gambar) 
             VALUES (NULL, ?, ?, ?, ?, ?);`,
            [data.judul, data.penulis, data.isi, tanggal, data.gambar || null]
        );

        return { insertId: result.insertId };
    } catch (err) {
        console.log(err);
        throw new Error(err); 
    } finally {
        if (conn) conn.release();
    }
};

const getAllArtikel = async () => {
    let conn;
    try {
        console.log('mengambil data');
        const conn = await pool.getConnection();
        const [result] = await conn.query(`SELECT * FROM artikel`);
        return result;
    } catch (err) {
        console.log(err);
        throw new Error(err); 
    } finally {
        if (conn) conn.release();
        console.log('selesai');
    }
}

const getArtikelById = async (id) => {
    let conn;
    try {
        console.log('mengambil data');
        const conn = await pool.getConnection();
        const [result] = await conn.query(`SELECT * FROM artikel WHERE id = ?`, [id]);
        return result;
    } catch (err) {
        console.log(err);
        throw new Error(err); 
    } finally {
        if (conn) conn.release();
        console.log('selesai');
    }
}

const updateArtikel = async (data, id, tanggal) => {
    let conn;
    try {
        conn = await pool.getConnection();

        const [result] = await conn.query(
            `UPDATE artikel SET judul = ?, penulis = ?, isi = ?, last_update = ?, gambar = ? WHERE id = ?`,
            [data.judul, data.penulis, data.isi, tanggal, data.gambar || null, id]
        );

        return result.affectedRows;
    } catch (err) {
        console.log(err);
        throw new Error(err); 
    } finally {
        if (conn) conn.release();
    }
};


const deleteArtikel = async (id) => {
    let conn;
    try {
        // For pool initialization, see above
        const conn = await pool.getConnection();
        const [result] = await conn.query(`DELETE FROM artikel WHERE id = ?`, [id]);
        // Connection is automatically released when query resolves
        return result;
    } catch (err) {
        console.log(err);
        throw new Error(err); 
    } finally {
        // Lepaskan koneksi ke pool
        if (conn) conn.release();
    }
}

module.exports = {
    getAllArtikel,
    getArtikelById,
    createArtikel,
    updateArtikel,
    deleteArtikel
}